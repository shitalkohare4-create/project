// Configuration
// ** REMEMBER to replace 'YOUR_API_KEY' with your actual key **
const API_KEY = 'YOUR_API_KEY'; 

// DOM Elements
const cityInput = document.getElementById('city-input');
const searchBtn = document.getElementById('search-btn');
const locationName = document.getElementById('location-name');
const loadingMsg = document.getElementById('loading-msg');
const tempDisplay = document.getElementById('temp-display');
const conditionsDisplay = document.getElementById('conditions-display');
const humidityDisplay = document.getElementById('humidity-display');
const windDisplay = document.getElementById('wind-display');
const forecastCards = document.getElementById('forecast-cards');
const forecastLoading = document.getElementById('forecast-loading');
const errorMessage = document.getElementById('error-message');


/**
 * Hides all data fields and shows a simple message.
 */
function resetDisplay(message = 'Loading...') {
    loadingMsg.textContent = message;
    loadingMsg.style.display = 'block';
    
    // Clear current data
    locationName.textContent = '...';
    tempDisplay.textContent = '--';
    conditionsDisplay.textContent = '--';
    humidityDisplay.textContent = '--';
    windDisplay.textContent = '--';

    // Clear forecast data, show loading message
    forecastCards.innerHTML = '';
    forecastLoading.style.display = 'block';
    errorMessage.style.display = 'none';
    errorMessage.textContent = '';
}

/**
 * Updates the current weather section with fetched data.
 * @param {object} data The current weather API response
 * @param {string} city The city name
 */
function displayCurrentWeather(data, city) {
    loadingMsg.style.display = 'none';
    locationName.textContent = city;
    tempDisplay.textContent = Math.round(data.main.temp);
    conditionsDisplay.textContent = data.weather[0].description;
    humidityDisplay.textContent = data.main.humidity;
    windDisplay.textContent = (data.wind.speed * 3.6).toFixed(1); // Convert m/s to km/h
}

/**
 * Updates the forecast section with fetched data.
 * (The logic here will need to filter and loop through the data)
 */
function displayForecast(data) {
    forecastLoading.style.display = 'none';
    
    // Example: Create a simple forecast card (you will expand this later)
    // forecastCards.innerHTML = '<div class="card">Day 1: 25°C</div>';
}


// Function to fetch data by city name (Your core logic will go here)
async function fetchWeatherByCity() {
    const city = cityInput.value.trim();
    if (!city) {
        errorMessage.textContent = 'Please enter a city name.';
        errorMessage.style.display = 'block';
        return;
    }
    
    resetDisplay(`Fetching data for ${city}...`);
    
    // 1. Get Coordinates using Geocoding API
    // 2. Use coordinates to call Current Weather API
    // 3. Use coordinates to call 5-Day Forecast API
    // 4. Call displayCurrentWeather() and displayForecast() with the results
    
    // *** YOUR API CALL LOGIC GOES HERE ***
    
    // Example Success Placeholder (Remove this once API calls are implemented):
    setTimeout(() => {
        // Assume you got good data
        displayCurrentWeather({
            main: { temp: 28.5, humidity: 65 },
            weather: [{ description: 'clear sky' }],
            wind: { speed: 4.1 }
        }, city);
        displayForecast({}); // Placeholder call
    }, 1000);
}


// Event Listener
searchBtn.addEventListener('click', fetchWeatherByCity);
cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        fetchWeatherByCity();
    }
});

// Initial load state
resetDisplay('Enter a city name and click "Get Weather"');